<#
.DESCRIPTION
    Clase para la generación automatizada de archivos de configuración, licencias y repositorios.
.INPUTS
    Ninguno.
.OUTPUTS
    [Generador]
.EXAMPLE
    $gen = [Generador]::new("all", "MiProyecto")
    $gen.crear()
#>
class Generador {
    [string]$Nombre
    [string]$Raiz
    [string]$RutAll

    <#
    .DESCRIPTION
        Constructor de la clase Generador.
    .PARAMETER nombre
        Nombre de la acción o plantilla a ejecutar ("all", "license").
    .PARAMETER raiz
        Ruta o nombre de la carpeta destino del proyecto.
    .INPUTS
        [string], [string]
    .OUTPUTS
        [Generador]
    .EXAMPLE
        $gen = [Generador]::new("license", "MiProyecto")
    #>
    Generador([string]$nombre, [string]$raiz) {
        $this.Nombre = $nombre
        $this.Raiz = $raiz

        $baseDir = Split-Path $PSScriptRoot -Parent
        $this.RutAll = Join-Path $baseDir $this.Raiz
    }

    <#
    .DESCRIPTION
        Instala una licencia de código abierto (GPLv3 o MIT) en el directorio del proyecto.
    .INPUTS
        Ninguno.
    .OUTPUTS
        [void]
    .EXAMPLE
        $gen.instalar_liscencia()
    #>
    [void] instalar_liscencia() {
        $LISCENCE = Read-Host "¿Qué licencia? (GPLv3/MIT): " -ForegroundColor Blue

        $nombreArchivo = switch ($LISCENCE) {
            "GPLv3" { "GNU-GPLv3.txt" }
            "MIT" { "MIT.txt" }
            default { $null }
        }

        if ($nombreArchivo) {
            $RutaPlantilla = Join-Path $PSScriptRoot "LICENSES\examples\$nombreArchivo"
            $Destino = Join-Path $this.RutAll "LICENSE"

            if (Test-Path $RutaPlantilla) {
                Copy-Item -Path $RutaPlantilla -Destination $Destino -Force
                Write-Host "Licencia $LISCENCE creada con éxito." -ForegroundColor Green
            }
            else {
                Write-Host "No se encontró el archivo de la plantilla en: $RutaPlantilla" -ForegroundColor Red
            }
        }
        else {
            Write-Host "Licencia no válida o no soportada." -ForegroundColor Yellow
        }
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] crear_structura([string]$lenguaje) {
        $configPath = Join-Path $PSScriptRoot "Config\config.json"

        if ($lenguaje -eq "multi") {
            Write-Host "--- Configuración de Proyecto Multi-lenguaje ---" -ForegroundColor Cyan
            $coreLang = Read-Host "¿Cuál será el lenguaje principal o core?"
            $testFolder = Read-Host "¿Cómo quieres nombrar la carpeta de pruebas? (ej. tests, spec)"

            # Creas las carpetas de forma dinámica con lo que el usuario ingresó
            $carpetasPersonalizadas = @("src", "core_$coreLang", $testFolder, "docs")

            foreach ($carpeta in $carpetasPersonalizadas) {
                $rutaCarpeta = Join-Path $this.RutAll $carpeta
                if (-not (Test-Path $rutaCarpeta)) {
                    New-Item -ItemType Directory -Path $rutaCarpeta -Force | Out-Null
                    Write-Host "Carpeta creada: $carpeta" -ForegroundColor Green
                }
            }
            Write-Host "Estructura multi-lenguaje generada con éxito." -ForegroundColor Green
            return
        }

        # Lógica normal para los demás lenguajes leídos del JSON...
        if (Test-Path $configPath) {
            $config = Get-Content -Path $configPath -Raw | ConvertFrom-Json
            $langConfig = $config.lenguajes.$lenguaje

            if ($langConfig -and $langConfig.PSObject.Properties['carpetas']) {
                foreach ($carpeta in $langConfig.carpetas) {
                    $rutaCarpeta = Join-Path $this.RutAll $carpeta
                    if (-not (Test-Path $rutaCarpeta)) {
                        New-Item -ItemType Directory -Path $rutaCarpeta -Force | Out-Null
                        Write-Host "Carpeta creada: $carpeta" -ForegroundColor Green
                    }
                }
                Write-Host "Estructura para '$lenguaje' creada con éxito." -ForegroundColor Green
            }
            else {
                Write-Host "El lenguaje '$lenguaje' no tiene carpetas definidas en el JSON." -ForegroundColor Yellow
            }
        }
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] instalar_git() {
        if (-not (Test-Path (Join-Path $this.RutAll ".git"))) {
            git -C $this.RutAll init
            git -C $this.RutAll branch -m main
            git -C $this.RutAll add .
            git -C $this.RutAll commit -m "chore(global): estructura incial creada"

            Write-Host "Repositorio Git inicializado con éxito." -ForegroundColor Green
        }
        else {
            Write-Host "El repositorio Git ya existe en esta ruta." -ForegroundColor Yellow
        }
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] configurar_git() {
        $RutaPlantilla = Join-Path $PSScriptRoot "Config\git-config\.gitignore-example"
        $Destino = Join-Path $this.RutAll ".gitignore"
        if (Test-Path $RutaPlantilla) {
            Copy-Item -Path $RutaPlantilla -Destination $Destino -Force
            Write-Host "Gitignore configurado." -ForegroundColor Green
        }
        else {
            Write-Host "No se encontró el archivo de la plantilla en: $RutaPlantilla" -ForegroundColor Red
        }

        $RutaPlantilla = Join-Path $PSScriptRoot "Config\git-config\.gitattributes-example"
        $Destino = Join-Path $this.RutAll ".gitattributes"
        if (Test-Path $RutaPlantilla) {
            Copy-Item -Path $RutaPlantilla -Destination $Destino -Force
            Write-Host "Gitattributes configurado." -ForegroundColor Green
        }
        else {
            Write-Host "No se encontró el archivo de la plantilla en: $RutaPlantilla" -ForegroundColor Red
        }

        $RutaPlantilla = Join-Path $PSScriptRoot "Config\git-config\.pre-commit-config_example.yaml"
        $Destino = Join-Path $this.RutAll ".pre-commit-config.yaml"
        if (Test-Path $RutaPlantilla) {
            Copy-Item -Path $RutaPlantilla -Destination $Destino -Force
            Write-Host ".pre-commit-config.yaml configurado." -ForegroundColor Green
        }
        else {
            Write-Host "No se encontró el archivo de la plantilla en: $RutaPlantilla" -ForegroundColor Red
        }
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] configurar_github() {
        $RutaPlantilla = Join-Path $PSScriptRoot "Config\git-config\github\workflows\ci.yml"
        $Destino = Join-Path $this.RutAll ".github\workflows\ci.yml"
        if (Test-Path $RutaPlantilla) {
            Copy-Item -Path $RutaPlantilla -Destination $Destino -Force
            Write-Host "GitHub configurado." -ForegroundColor Green
        }
        else {
            Write-Host "No se encontró el archivo de la plantilla en: $RutaPlantilla" -ForegroundColor Red
        }
        $RutaPlantilla = Join-Path $PSScriptRoot "Config\git-config\github\copilot-instructions.md"
        $Destino = Join-Path $this.RutAll ".github\copilot-instructions.md"
        if (Test-Path $RutaPlantilla) {
            Copy-Item -Path $RutaPlantilla -Destination $Destino -Force
            Write-Host "GitHub configurado." -ForegroundColor Green
        }
        else {
            Write-Host "No se encontró el archivo de la plantilla en: $RutaPlantilla" -ForegroundColor Red
        }
        $RutaPlantilla = Join-Path $PSScriptRoot "Config\git-config\github\dependabot.yml"
        $Destino = Join-Path $this.RutAll ".github\dependabot.yml"
        if (Test-Path $RutaPlantilla) {
            Copy-Item -Path $RutaPlantilla -Destination $Destino -Force
            Write-Host "GitHub configurado." -ForegroundColor Green
        }
        else {
            Write-Host "No se encontró el archivo de la plantilla en: $RutaPlantilla" -ForegroundColor Red
        }
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] configurar_gitlab() {
        $RutaPlantilla = Join-Path $PSScriptRoot "Config\git-config\github\dependabot.yml"
        $Destino = Join-Path $this.RutAll ".github\dependabot.yml"
        if (Test-Path $RutaPlantilla) {
            Copy-Item -Path $RutaPlantilla -Destination $Destino -Force
            Write-Host "GitHub configurado." -ForegroundColor Green
        }
        else {
            Write-Host "No se encontró el archivo de la plantilla en: $RutaPlantilla" -ForegroundColor Red
        }
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] configurar_gobernansa() {
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] configurar_changes() {
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] configurar_AI() {
    }

    <#
    .DESCRIPTION
    .INPUTS
    .OUTPUTS
    .EXAMPLE
    #>
    [void] configurar_vscode() {

    }

    <#
    .DESCRIPTION
        Ejecuta la lógica de creación según la opción seleccionada en el nombre.
    .INPUTS
        Ninguno.
    .OUTPUTS
        [void]
    .EXAMPLE
        $gen.crear()
    #>
    [void] crear() {
        switch ($this.Nombre.ToLower()) {
            "all" {
                $this.instalar_liscencia()

            }
            "license" {
                $this.instalar_liscencia()
            }
            default {
                Write-Host "Opción no reconocida: $($this.Nombre)" -ForegroundColor Yellow
            }
        }
    }
}
